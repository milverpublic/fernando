CREATE TRIGGER response_questions
AFTER INSERT OR UPDATE ON response_questions
FOR EACH ROW EXECUTE PROCEDURE update_control_reponses()